sequencia para criar projeto

criar projeto em react
## npx create-react-app + nome do projeto

acessar diretorio do projeto
## cd (nome do projeto)

executar projeto
 ## npm start

 gerenciador de rota front
## npm i --save react-router-dom

realizar conexão com API
## npm install --save axios